[F]antastic [F]letcher, broughht to you by -daazndagger-. 
A free public script, only downloadable at villavu.com/forums!

Please thread for setup details:
  http://villavu.com/forum/showthread.php?t=95698&p=1164488
